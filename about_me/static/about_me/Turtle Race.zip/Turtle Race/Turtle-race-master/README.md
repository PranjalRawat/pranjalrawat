# Turtle-race
- must have python installed in system
- just run the code
